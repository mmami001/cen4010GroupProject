import React from "react";


export class Register extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {

    const valid = (item) => {

      let text = document.querySelector(`#${item}`);
      text.style.opacity = 0;

    }
    const invalid = (item) => {

      let text = document.querySelector(`#${item}`);
      text.style.opacity = 1;

    }

    const handleInputChange = e =>{
    const password = e.target.value;

    if (password.length > 7){
      valid("more8");
    }else{
      invalid("more8");
    }

    };

    const confirmInputChange = e =>{
      const password = document.querySelector('.origPassword').value;
      const confPassword = e.target.value;
  
      if (confPassword == password){
        valid("match");
      }else{
        invalid("match");
      }
  
      };



    return (
      <div className="base-container" ref={this.props.containerRef}>
        <div className="header">Register</div>
        <div className="content">
          
          <div className="form">
            <div className="form-group">
              <label htmlFor="username">User ID</label>
              <input type="text" name="username" placeholder="UserID" />
            </div>
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input 
                class="origPassword"
                type="password" 
                name="password" 
                placeholder="Password" 
                onChange = {handleInputChange}
                />
                

            </div>
            <div className="form-group">
              <label htmlFor="password">Confirm Password</label>
              <input type="password" name="password" placeholder="Confirm Password" 
              onChange = {confirmInputChange}
              />
      
            </div>
          </div>

          <p id = "more8">
                  <span>Password must be atleast 8 characters</span>
                </p>

          <p id = "match">
                  <span>Passwords must match</span>
                </p>

        </div>
        <div className="footer">
          <button type="button" className="btn">
            Register
          </button>
        </div>
      </div>
    );
  }
}
